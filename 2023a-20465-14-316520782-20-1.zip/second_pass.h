/* 
 * param:
 * info_of_line
 * pross_table*
 * return:
 * boolean value(true or false)
 */
bool second_pass(info_of_line line_info, pross_table *file_tables);
/*
 * param:
 * symbol_table*
 * char*
 * return:
 * integer(a complete number)
 */
int labAdd(symbol_table* table, char* name);
/*
 * param:
 * info_of_line
 * pross_table*
 * char []
 * return:
 * boolean value ( true of false )
 */
bool kidudSymbol(info_of_line line_info,pross_table* file_table, char  word[]);
/*
 * param:
 * info_of_line
 * char*
 * symbol_table*
 * return:
 * boolean value(true or false)
 */
bool checkEntry2(info_of_line line_info,char *word,symbol_table *table);
/*
 * param:
 * info_of_line
 * char*
 * return:
 * boolean value(true or false)
 */
bool blankCheck(info_of_line line_info,char * word);
/*
 * param:
 * info_of_line
 * pross_table *
 * char*
 * action:
 * coding the symbol of the JUMP hashing method
 * return:
 * boolean value ( true or false)
 */
bool kidudSymbolWithJump(info_of_line line_info,pross_table* file_table, char *label);
/*
 * param:
 * info_of_line
 * pross_table*
 * integer
 * action:
 * coding the symbol of 1 operator instruction , not a JUMP hashing method
 * return:
 * boolean value ( true or false)
 */
bool kidudSymbolWith1Op(info_of_line line_info,pross_table* file_table,int i);
/*
 * param:
 * info_of_line
 * pross_table*
 * action: 
 * coding the symbol of 2 operator instruction
 * return:
 * boolean value ( true or false)
 */
bool kidudSymbolWith2Op(info_of_line line_info,pross_table* file_table);


