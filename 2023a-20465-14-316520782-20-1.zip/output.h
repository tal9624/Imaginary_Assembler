
/*
 * param:
 * pross_table*
 * int
 * int
 * char*
 * action:
 * will give us the files 
 * of the entry symbols, extern symbols and the machine code file.
 * entry symbol and extern symbol files would be as an output if
 * there are entry symbols and extern symbols
 */	
void output(pross_table *file_tables, int ic, int dc, char* name);
/*
 * param:
 * symbol_table*
 * char*
 * action:
 * checks how many nodes are in the entry table. for zeyro return. 
 * else will call the func printEntTables 
 */
void entTables(symbol_table *table, char* name);
/*
 * param:
 * symbol_table*
 * char*
 * action:
 * printing the entry symbols to the ps.ent file 
 */
void printEntTables(symbol_table *table, char* name);
/*
 * param:
 * symbol_table*
 * char*
 * action:
 * checks how many nodes are in the extern table. for zeyro return. 
 * else will call the func printExTables
 */
void exTables(symbol_table *ExSymbol, char* name);
/*
 * param:
 * symbol_table*
 * char*
 * action:
 * printing the extern symbols to the ps.ent file
 */
void printExTables(symbol_table *ExSymbol, char* name);
/* */
/*
 * param:
 * table*
 * table*
 * int
 * int
 * char*
 * action:
 * printing the '.' and '/' to the "ps.ob" file according to the data table
 */
void encoding(table* out1, table* out2, int arr1Len , int arr2Len, char* name);



