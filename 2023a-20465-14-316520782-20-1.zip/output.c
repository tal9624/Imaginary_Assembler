#include "dataStructure.h"
#include "output.h"
/* the main function of outputs. will give us the files 
of the entry symbols, extern symbols and the machine code file.
entry symbol and extern symbol files would be as an output if
there are entry symbols and extern symbols */
void output(pross_table *file_tables, int ic, int dc, char *name)
{	
 	char entName[FILE_NAME_MAX];
	char extName[FILE_NAME_MAX];
	name = strtok(name,".");/* cutting the finisher ".am" from the original file */
	strcpy(entName,  name);
	strcat(entName,".ent");/* for the entry file , puts a finisher ".ent " */
	strcpy(extName, name);
	strcat(extName,".ext");/* for the extern file , puts a finisher ".ext " */
	entTables(&(file_tables->symbolTable), entName);
	exTables(&(file_tables->ExSymbol), extName);	
	strcat(name,".ob");/* for the code file , puts a finisher ".ob" */
	encoding((file_tables->code_table), (file_tables->data_table), IC , DC, name);
	
}/* end of function */
/* checks how many nodes are in entry table 
if zero then return without doing anythings . otherwise 
will print the entry table */
void entTables(symbol_table *table, char *name)
{
	int count = 0;	
	symbol* node;
	node = *table;
	while (node != NULL)
    {/* loop for checking if theres an entry label */
        if(node->type == ENTRY_Sym )
			count++;
        node = node->next;
    } /* end of loop */
	if(count == 0) /* no entry labels */
		return;
	else
	{		
		printEntTables(table, name);
	}
}/* end of function */
/*printing the entry symbols to the ps.ent file 
would not print anything if there arnt any appropriate symbols
thanks to the func entTables */
void printEntTables(symbol_table *table, char* name)
{
	symbol* node;	
	FILE *ent = fopen(name, "w");/* opening the entry file */
	node = *table;
	while (node != NULL)
    {/* printing the entries to the file */
		if(node->type == ENTRY_Sym )
        	fprintf(ent,"%s   %d\n",node->name,((node->address)+LINENUM_INITIAL));
        node = node->next;
    }
}/* end of function */
/* checks if the extern symbols tabels is empty. if it is do nothing  */ 
void exTables(symbol_table *ExSymbol, char *name)
{  
 /* check if the table exists and if theres symbols on the table*/
    if (ExSymbol == NULL || *ExSymbol == NULL)
    { /* no exteral labels */
      return;
    }    
   
	printExTables(ExSymbol, name);	
}/* end of functions */
/*printing the extern symbols to the ps.ent file
would not print anything if there arnt any appropriate symbols 
thanks to the func exTables */
void printExTables(symbol_table *ExSymbol, char* name)
{
	symbol* node;		
	FILE *ext = fopen(name, "w");
    node = *ExSymbol;
    
    while (node != NULL)
    {/*each iteration, printing to the ext file */ 
        fprintf(ext,"%s   %d\n",node->name,((node->address)+LINENUM_INITIAL));
        node = node->next;
    } /* end of loop */
}/* end of function */
/* printing the '.' and '/' to the "ps.ob" file */
void encoding(table* out1, table* out2, int arr1Len , int arr2Len, char* name)
{
	int i,j;
	FILE *f = fopen(name, "w"); /* opening the file to write to */
	int address = LINENUM_INITIAL;
	fprintf(f,"\t\t%d  %d  ",arr1Len , arr2Len);
    for(i=0;i<arr1Len; i++) /* running on the code array */
    {
        fprintf(f, "\n0%d\t\t",address++); /* printing the adress first */
		for (j = NUM_OF_BITS-1; j >= 0; j--) /* running through the bits */
		{
			if ((out1[i].code) & (1 << j))
				fprintf(f, "/");
            else
               	fprintf(f,"."); 
		}/* end of loop */
	}/* end of loop */
    for(i=0;i<arr2Len; i++) /* running on the data table array */
    {
        fprintf(f, "\n0%d\t\t",address++);/* printing the adress first */
		for (j = NUM_OF_BITS-1; j >= 0; j--) /* running through the bits */
		{
			if ((out2[i].code) & (1 << j))
				fprintf(f, "/");
            else
               	fprintf(f,"."); 
		}/* end of loop */
	}/* end of loop */
}/* end of function */
