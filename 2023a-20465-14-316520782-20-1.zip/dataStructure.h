#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define SKIP_WHITESPACE(str) \
        while(*(str) && (*(str) == ' ' || *(str) == '\t')) \
        (str)++;

#define LINELEN 81
#define LABELMAX 30
#define TABLE_MAX 1000
#define COMMAND_MAX 10
#define MAX_HASH_METHOD 4
#define FILE_NAME_MAX 30
#define LINENUM_INITIAL 100
#define NUM_OF_BITS 14
#define EX_SYM 1
#define ARE_SKIP 2
#define REG_NUMBER 8
#define SOURCE_REG_SKIP 8
#define OPCODE_SKIP 6
#define PARAM_ONE_HASH 10
#define PARAM_TWO_HASH 12
#define TWO_REG_HASH 15
#define HASH_SOURCE_OP 4
/*global integers*/
extern int IC , DC ;   
/* Addressing mode type */
typedef enum addrs_method
{
    IMMEDIATE = 0,
    DIRECT = 1,
    JUMP = 2,
    DIRECT_REG = 3,
    NONE_ADDRS = -1
} addrs_method;

typedef struct value
{
	addrs_method adr;
	char * opName;
}value;
/*struct of opcode with 2 operators sorce and destination*/
typedef struct opCode2
{
	short commandNumber;
	char commandName[COMMAND_MAX];
    int opSourceLen; 
    addrs_method opSource[MAX_HASH_METHOD];
    int opDestinLen;
    addrs_method opDestination[MAX_HASH_METHOD];

}opCode2;

/*struct of opcode with 1 operator just destination*/



typedef struct opCode1
{
	int commandNumber;
	char commandName[COMMAND_MAX];
	int opDestinLen;
    addrs_method opDestination[MAX_HASH_METHOD];
    

}opCode1;

/*struct of opcode without operators */
typedef struct opCode0
{
	int commandNumber;
	char commandName[COMMAND_MAX];

}opCode0;

/** Define the symbol type */
typedef enum sym_type 
{
    ENTRY_Sym,
    DATA_Sym,
    CODE_Sym,
    EXTERNAL_Sym,
    NONE_Sym
} sym_type;


/* the definition of a linkedlist for the symbols named symbol */ 
typedef struct symbol
{
    /** The name of the symbol */
    char name[LINELEN];
    /** The type of the symbol */
    sym_type type;
    /** The symbol memory address, by base & offset */
    int address;
    /** The next Symbol entry */
    struct symbol* next;

} symbol;
/** Code type */
typedef enum code_type
{
    INSTRUCTION,
    OPCODE,
    DATA
} code_type;

/*pattern table */
typedef struct table{
    int address;
    short code;
}table;
/* definition of symbol */
typedef symbol *symbol_table;

typedef struct pross_table 
{
    table code_table[TABLE_MAX];
    table data_table[TABLE_MAX];
    /* Symbol_table is just pointer to symbol*/
    symbol_table symbolTable;
	symbol_table ExSymbol;

}pross_table;

/** Instruction type (.data/ .string/ .extern/ .entry) */
typedef enum instruction
{
    DATA_INST,
    STRING_INST,
    ENTRY_INST,
    EXTERN_INST,
    NONE_INST
} instruction;

/* Define structure & array to search for instruction */
typedef struct search_inst
{
    char *name_inst;
    instruction value_inst;
} search_inst;

typedef struct info_of_line
{
    /* the file name */
    char *file_name;
    
    /* the line number in the file */
    unsigned long line_num;
    
    /* pointer to a string that contains the contents of the line */
    char *text;
    
} info_of_line;



/* 
 * param:
 * char*
 * action:
 * checks if the symbol is legal
 * return:
 * integer ( 0 for not legal and 1 for legal )
 */
int CheckTheLabelName(char *labelName);
/* 
 * param:
 * char*
 * return:
 * instruction
 */
instruction findInst(char *str);
/* 
 * param:
 * char*
 * return:
 * the type of the operand
 */
addrs_method addressType(char* word);
/* 
 * param:
 * symbol_table*
 * action:
 * adding a node to the end of the linked list of the symbols
 */
void add_symbol(symbol_table *table, symbol *sym);
/* 
 * param:
 * char*
 * sym_type
 * unsigned int
 * action:
 * creating a node which represents a symbol 
 */
symbol *create_symbol(char *name, sym_type tp, unsigned int ad);
/* 
 * param:
 * symbol_table*
 * char*
 * action:
 * check if the symbol is on the symbol table
 * return:
 * if the symbol is not on the symbol table will return NULL
 */
symbol* find_symbol(symbol_table *table, char *name);
/* 
 * param:
 * symbol_table*
 * action:
 * freeing the link list , step by step
 */
void del_symbol_table(symbol_table *table);
/* 
 * param:
 * symbol*
 * action:
 * freeing a node
 */
void free_symbol(symbol *sym);



