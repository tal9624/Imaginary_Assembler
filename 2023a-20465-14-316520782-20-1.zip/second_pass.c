#include "dataStructure.h"
#include "second_pass.h"
/* checking for blank lines */

/*opcode type: 2 operators array*/
static opCode2 opCodeVal2Op[]= 
{
    {0 ,"mov",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {1 ,"cmp",3,{IMMEDIATE,DIRECT,DIRECT_REG},3,{IMMEDIATE,DIRECT_REG,DIRECT}},
    {2 ,"add",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {3 ,"sub",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {6 ,"lea",1,{DIRECT},2,{DIRECT,DIRECT_REG}},

};

/*opcode type 1 operator array*/
static opCode1 opCodeVal1Op[] = 
{
    {4 ,"not",2,{DIRECT,DIRECT_REG}},
    {5 ,"clr",2,{DIRECT,DIRECT_REG}},
    {7 ,"inc",2,{DIRECT,DIRECT_REG}},
    {8 ,"dec",2,{DIRECT,DIRECT_REG}},
    {9 ,"jmp",3,{DIRECT,JUMP,DIRECT_REG}},
    {10 ,"bne",3,{DIRECT,JUMP,DIRECT_REG}},
    {11 ,"red",2,{DIRECT,DIRECT_REG}},
    {12 ,"prn",4,{IMMEDIATE,DIRECT,DIRECT_REG}},
    {13 ,"jsr",3,{DIRECT,JUMP,DIRECT_REG}},
};

/*opcode type: 0 operators array*/
static opCode0 opCodeValZOp[] = 
{
    {14 ,"rts"},
    {15 ,"stop"},
};

/* a main procedure the second pass!
will go through the line sent from the file and determine 
for each word if its a label , a register , an instruction ..
and will send it to the right functin to keep the coding process */
bool second_pass(info_of_line line_info, pross_table *file_tables)
{	
	instruction current_inst;
	char word[LINELEN];
    SKIP_WHITESPACE(line_info.text);/*go to the first place in the line with char*/
    while((sscanf(line_info.text, "%s", word)) != '\n')
    {	 
       	/* check for a blank line */
      	 if (blankCheck(line_info,word))
		 {
     	   return true; /* when line contains only spaces return true */
    	 }  
    	 if( word[0] == ';' )
    	 {
            return true; /* when line starts with a ';' return true */
         }       
         if ((*(word + (strlen(word) - 1)) == ':')) /* found a label! */
         {
          /*on the second pass we "ignore" the label and go to the next word in this case */
        	  line_info.text += (strlen(word));
         	  SKIP_WHITESPACE(line_info.text);
          continue;
          }  
          if(*word == '.') /*found a point operator which implies for a special instruction */
          { 
            current_inst = findInst(word+1);
            if (current_inst == ENTRY_INST)
            {
            	  line_info.text += (strlen(word));
        		  SKIP_WHITESPACE(line_info.text);
            	  sscanf(line_info.text, "%s", word);
            	  return checkEntry2(line_info,word,&(file_tables->symbolTable));
            }
            else return true;
          }         
          return kidudSymbol(line_info,file_tables, word);
 	}/* end of while loop */
 	return true;
}/* end of function */


/* A function that returns the address of the label , if not found returns -1 */
int labAdd(symbol_table* table, char* name)
{	
	symbol* node;
   	 if (table == NULL || *table == NULL)
   	 {    	 
     	   return -1;
   	 }
    	node = *table; 
   	 while (node!= NULL)
    {
    	
    	if((!strcmp(node->name,name))){
    	return node->address;}
    	else    	
      	  node = node->next;      	        	  
   	 }/* end of while loop */
   	 return -1;
}/* end of function */



/* coding the symbol to the table */
bool kidudSymbol(info_of_line line_info,pross_table* file_table, char  word[])
{

	int i;
    /***************************************************************************/
    /********************** check for 2 operands *******************************/
    for(i=0;i<(sizeof(opCodeVal2Op) / sizeof(struct opCode2));i++)
    {

        if (!strcmp(word,opCodeVal2Op[i].commandName))
        {
        	IC++;
        	line_info.text += (strlen(word)); /* going to the next word */
        	SKIP_WHITESPACE(line_info.text);
        	return kidudSymbolWith2Op(line_info,file_table);
        }
  
    }/* end of for loop */


    /***************************************************************************/
    /********************** check for 1 operands *******************************/
    for(i=0;i<(sizeof(opCodeVal1Op) / sizeof(struct opCode1));i++)
    {
        if (!strcmp(word,opCodeVal1Op[i].commandName))
        {
        	line_info.text += (strlen(word)); /* going to the next word */ 
       		SKIP_WHITESPACE(line_info.text);
       		IC++; 
			return kidudSymbolWith1Op(line_info,file_table,i);
       		
       }
    }/* end of outer for loop */
      
    /***************************************************************************/
    /********************** check for 0 operands *******************************/
    for(i=0;i<(sizeof(opCodeValZOp) / sizeof(struct opCode0));i++)
    {
      if (!strcmp(word,opCodeValZOp[i].commandName))
      {     /*found the opcode */ 	
           IC++;
           return true;
      }
    } /* end of outer for loop */

    /* and if we got here , its because we didnt find the opcode name*/
	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
	printf("ERROR: The input String is Wrong because of a nonexisting opcode\n");    	
	return false; 

}/* end of function */

/* this functions checks if the ENTRY label is  in the symbol linked list 
and updates the node if so, aftet that will return true . else will return  false*/
bool checkEntry2(info_of_line line_info,char *word,symbol_table *table)
{
   char name[LINELEN]; /* an array with a max length of a line */ 
   symbol* node;
   if ((sscanf(word, "%s",name) == '\n')) /* if the label is empty */
   {
    printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
	printf("ERROR: entry field must contain a legit label\n");  
   return false;
   }
   else
   {  
     node = *table;  /* initiate node to the start of the table */  
     while (node != NULL)
     {
        if (!strcmp(node->name, name)) /* if found, update the pointer */
        {
        	node->type = ENTRY_Sym; /* update */
            return true;           
        }
        node = node->next;
     }/* end of while loop */    
   }
   /* since we didnt find the symbol well return an ERROR */
	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
	printf("ERROR: cant find the entry label on the label table\n");  
	return false; /* if not found, return false */
}/* end of function */

/* checking for labels within the 2 operands. if labels are found, well check if theyre external or regular labels . and then code them. if its node a symbol well skip it. */ 
bool kidudSymbolWith2Op(info_of_line line_info,pross_table* file_table){
 
	bool found = false;
    int sym;
	symbol *exsymbol;
    char* tok;
    value addrs1;/* addrs1 and 2 will represent the operands of the opcode */
    value addrs2;
    addrs_method address; /* represents the hashing method for the operand */
     /*important initialization because if the hashing method wont be found on the 
    SEARCHING LOOP , well stay with this value and return an ERROR */ 
    addrs1.adr = NONE_ADDRS;
    addrs2.adr = NONE_ADDRS;

	tok = strtok(line_info.text, ",");
    /*saving the names of the 2 operands on the while loop */
    while (tok != NULL)
    {  
    	address = addressType(tok);
        if (!found)
        {
        	addrs1.adr = address;
            addrs1.opName = tok;
 			found = true; /* saved the first operand , now when found is true , on the next iteration will save the second one */
        }
        else
        {
        	addrs2.adr = address;
            addrs2.opName = tok;                                 
		}
		tok = strtok(NULL, ",");           
     }/* end of while loop */

     if (strchr(addrs2.opName,'\n'))
     {
     	*strchr(addrs2.opName,'\n') = '\0';
     }

     if ( addrs1.adr == DIRECT_REG && addrs2.adr == DIRECT_REG ) /*checking if the two operand direct reg*/
     {   
      	IC++;
      	return true;
     } 
     else
     {

      /*********************************checking the first operand *********************************/
      	if ( addrs1.adr == DIRECT )/* if the first operand is a label, it needs a 											 direct hashing method  */
      	{
        	sym = labAdd((&(file_table->symbolTable)), addrs1.opName);
         	if (sym == -1) /* means the symbol doesnt exists in the symbol table*/
         	{
   				printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 			printf("Symbol doesnt exist since it hasnt been added in first pass\n");
              	return false;
         	}
         	/* if the symbol is external symbol */
         	if (find_symbol(&(file_table->symbolTable),  addrs1.opName)->type == EXTERNAL_Sym )
          	{  
				/* coding th symbol */
 				exsymbol = create_symbol( addrs1.opName, EXTERNAL_Sym, IC);
            	add_symbol((&(file_table->ExSymbol)), exsymbol);
            	file_table->code_table[IC].code |= EX_SYM ;
             	IC++;
          	}

           	/* if the symbol is not external */
           	else
           	{           	        
            	sym = labAdd((&(file_table->symbolTable)), addrs1.opName);
              	file_table->code_table[IC].code = CODE_Sym;
              	file_table->code_table[IC].code |= (sym+LINENUM_INITIAL) << ARE_SKIP;
				IC++; 
        	}
     	}
     	else  /* if the operand is not a symbol*/
     	{
         	IC++;
   		}    
      /*********************************checking the second operand 				*********************************/
        if ( addrs2.adr == DIRECT )/* if the second operand is a label, it needs a 											       direct hashing method  */
       	{  
         	sym = labAdd((&(file_table->symbolTable)), addrs2.opName);

          	if (sym ==-1)/* means the symbol doesnt exists in the symbol table*/
          	{ 
            	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 			printf("Symbol doesnt exist since it hasnt been added");
   	 			printf("in the first pass\n");
         		return false;
        	}
          	/* if the symbol is external symbol */
         	if (find_symbol(&(file_table->symbolTable),  addrs2.opName)->type == EXTERNAL_Sym )
          	{
				/* coding the symbol */
 				exsymbol = create_symbol( addrs2.opName, EXTERNAL_Sym, IC);
              	add_symbol((&(file_table->ExSymbol)), exsymbol);
               	file_table->code_table[IC].code |= EX_SYM ;
				IC++;
          	}
          	/* if the symbol is not external */
           	else
          	{
				/* coding th symbol */
          		file_table->code_table[IC].code = CODE_Sym;
              	file_table->code_table[IC].code |= (sym+LINENUM_INITIAL) << ARE_SKIP;
				 IC++;
         	}
     	}
       	else  /* if the operand is not a symbol*/
       	{
         	IC++;
     	}
   	}
  	return true;       
} /*end of function */

/* checking for labels within the 1 operands.first well check for jump hashing and code  if labels are found, well check if theyre external or regular labels . and then code them. if its node a symbol well skip it. */ 
bool kidudSymbolWith1Op(info_of_line line_info,pross_table* file_table,int i)
{
    int sym;
	symbol *exsymbol;
    char label[LABELMAX]; 
    int j;
	value addrs1;/* addrs1 and 2 will represent the operands of the opcode */

    addrs_method address; /* represents the hashing method for the operand */
     /*important initialization because if the hashing method wont be found on the 
    SEARCHING LOOP , well stay with this value and return an ERROR */ 
    addrs1.adr = NONE_ADDRS;

	address = addressType(line_info.text); 
	/* searing for the opcode */
	for(j=0;j <= opCodeVal1Op[i].opDestinLen ;j++)
    {
    	if (address == opCodeVal1Op[i].opDestination[j])
       	{
        	addrs1.adr = address;
         	addrs1.opName = line_info.text;
         	if (strchr(addrs1.opName,'\n'))
          	{
           		*strchr(addrs1.opName,'\n') = '\0';
          	}                 
     	}
   	}/* end of for inside loop */
   	
 	/* since that our searcing loop is going through each opcode that we found , if the opcode is not prn then addrs2.adr wont be immediate because our array 		"opCodeVal10p" contains the IMMEDIATE hashing method only for the prn type of instrction . for every other try to attempt an IMMEDIATE type of hashing ( for 		example "red #1" ) the addrs will remain NON_ADDRS which is -1 */ 
 	if(addrs1.adr == IMMEDIATE)
 	{
     	IC++;
     	return true; 
   	}

   	if (addrs1.adr == DIRECT_REG)
   	{ /* if the first operand is a register */
     	IC++;
		return true;
	}
	
  	if(addrs1.adr == DIRECT) /* if the operand is a label */
   	{
	 	/* since the operand is a label well check if its on hashing method 2 */
   		if (!strcmp(opCodeVal1Op[i].commandName,"jmp") || !strcmp(opCodeVal1Op[i].commandName,"jsr") || !strcmp(opCodeVal1Op[i].commandName,"bne"))
   		{

	   		for(i=0 ;(*(line_info.text) != '\0') && (*(line_info.text) != '(') ;line_info.text++,i++)
       		{ 
				/* saving the label*/
        		label[i] = *(line_info.text);        			
       		}/* end of for inside loop */

			label[i] = '\0';

			/* if theres only one label */				
    		if (*(line_info.text) == '\0')/* if theres only one label */	
      		{              
      			if(find_symbol(&(file_table->symbolTable), label) == NULL) 
        		{  /* label doesnt exists */
              		printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 				printf("Symbol doesnt exist since it hasnt been");
   	 				printf("added in first pass\n");
             		return false;
           		}
         		if (find_symbol(&(file_table->symbolTable), label)->type == EXTERNAL_Sym )
           		{ 
					/* if the label is an external type */
					exsymbol = create_symbol(label, EXTERNAL_Sym, IC);
            		add_symbol((&(file_table->ExSymbol)), exsymbol);
              		file_table->code_table[IC].code |=EX_SYM ;
             		IC++;
             		return true;
        		}
          		else/* if the label is not external */	
           		{	
					/* saving the label number */			
            		sym = labAdd((&(file_table->symbolTable)), addrs1.opName);
             		file_table->code_table[IC].code = CODE_Sym;
             		file_table->code_table[IC].code |= (sym+LINENUM_INITIAL) << ARE_SKIP;
              		IC++;
             		return true;
         		}
       		}
      		else if (*(line_info.text) == '(') 
       		{ 
				/* now we know we have 2 more operands to cehck */
         	 	return kidudSymbolWithJump(line_info,file_table, label);
       		}
   		}
   		else /* if the opcode is just one operand type , without the JUMP hashing
            since weve already checked if its a DIRECT_REG or IIMEDIATE it has to be a DIRECT label */
       	{           
         	if    (find_symbol(&(file_table->symbolTable),addrs1.opName) == NULL) 
          	{		
				/* label doesnt exists */
              	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 			printf("Symbol doesnt exist since it hasnt been added in first pass\n");
              	return false;
         	}
         	else  if (find_symbol(&(file_table->symbolTable), addrs1.opName)->type == EXTERNAL_Sym )
         	{		
				/* label is external */			
				exsymbol = create_symbol(addrs1.opName, EXTERNAL_Sym, IC);
              	add_symbol((&(file_table->ExSymbol)), exsymbol);
            	file_table->code_table[IC].code |= EX_SYM ;
             	IC++;
         	}
         	else
         	{	
				/* label is not external */				
             	sym = labAdd((&(file_table->symbolTable)), addrs1.opName);
              	file_table->code_table[IC].code = CODE_Sym;
             	file_table->code_table[IC].code |= (sym+LINENUM_INITIAL) << ARE_SKIP;
             	IC++;
             	 return true;
          	}
       	}
   	}           
 	return true;
}

/* checking for labels within the jump hashing operands, well check if theyre external or regular and then code them. if its not a symbol well skip it. */ 
bool kidudSymbolWithJump(info_of_line line_info,pross_table* file_table,  char *label)
{
	bool found = false;
    int sym;
	symbol *exsymbol;
    char* tok;

    value addrs1;/* addrs1 and 2 will represent the operands of the opcode */
    value addrs2;
    addrs_method address; /* represents the hashing method for the operand */
     /*important initialization because if the hashing method wont be found on the 
    SEARCHING LOOP , well stay with this value and return an ERROR */ 
    addrs1.adr = NONE_ADDRS;
    addrs2.adr = NONE_ADDRS;

	if(find_symbol(&(file_table->symbolTable), label) == NULL)
  	{  
		/* the label doesnt exists */
     	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 	printf("Symbol doesnt exist since it hasnt been");
   		printf("added in first pass\n");
      	return false;
	}
	else /* the label does exists */
	{ 
		/*adding the lael number */
     	sym = labAdd((&(file_table->symbolTable)), label);                      	
		if (find_symbol(&(file_table->symbolTable), label)->type == EXTERNAL_Sym )
     	{        
			/* the label is external */            	
			exsymbol = create_symbol(label, EXTERNAL_Sym, IC);
          	add_symbol((&(file_table->ExSymbol)), exsymbol);
          	file_table->code_table[IC].code |= EX_SYM ;
          	IC++;
      	}
     	else
 		{ 
			/* the label is not external */                    
       		file_table->code_table[IC].code = CODE_Sym;
           	file_table->code_table[IC].code |= (sym+LINENUM_INITIAL) << ARE_SKIP;
         	IC++;
      	}       	
       	tok = strtok((line_info.text+1), ",");
      	found =false;
      	/* finding the 2 more operand types */
      	while (tok != NULL)
     	{
         	address = addressType(tok);

        	if (!found)
         	{
            	addrs1.adr = address;
             	addrs1.opName = tok;
 				found = true;/* done with the first operand , now at the next iteration well go to the second one */
           	}
          	else
          	{
              	if (strchr(tok,')'))
               	{
                	*strchr(tok,')') = '\0';
               	}

              	address = addressType(tok);
             	addrs2.adr = address;
             	addrs2.opName = tok;                           
			}
			tok = strtok(NULL, ",");  
      	}/* end of while loop */
       	if ( addrs1.adr == DIRECT_REG && addrs2.adr == DIRECT_REG )
      	{
			/* both are registers */
           	IC++;
          	return true;
      	}
      	else
      	{
 		/*********************************checking the first operand *********************************/
     		if ( addrs1.adr == DIRECT )
           	{
				/* first operand is a label */
             	if    (find_symbol(&(file_table->symbolTable), addrs1.opName) == NULL) 
             	{/* label doesnt exists */
             		printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 				printf("Symbol doesnt exist since it hasnt been"); 
   	 				printf("added in first pass\n");
              	  	return false;
            	}
            	if (find_symbol(&(file_table->symbolTable), addrs1.opName)->type == EXTERNAL_Sym )
             	{
					/* label is external */
					exsymbol = create_symbol(addrs1.opName, EXTERNAL_Sym, IC);
                  	add_symbol((&(file_table->ExSymbol)), exsymbol);
                 	file_table->code_table[IC].code |= EX_SYM ;
                  	IC++;
               	}
             	else
              	{
					/* label is not external */
              	  	sym = labAdd((&(file_table->symbolTable)), addrs1.opName);
              	  	file_table->code_table[IC].code = CODE_Sym;
               	 	file_table->code_table[IC].code |= (sym+LINENUM_INITIAL) << ARE_SKIP;
               	 	IC++;
              	}
          	}
         	else /* its not a label */
          	{
           		IC++;
          	}
      	}
 		/*********************************checking the second operand *********************************/
       	if ( addrs2.adr == DIRECT )
      	{
			/* second operand is a label */
         	if    (find_symbol(&(file_table->symbolTable), addrs2.opName) == NULL) 
           	{  
				 /* label doesnt exists */         		
            	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
   	 			printf("Symbol doesnt exist since it hasnt been");
   	 			printf("added in the first pass\n");
              	return false;
          	}
          	if (find_symbol(&(file_table->symbolTable), addrs2.opName)->type == EXTERNAL_Sym )
          	{	
				/* label is external */
				exsymbol = create_symbol(addrs2.opName, EXTERNAL_Sym, IC);
               	add_symbol((&(file_table->ExSymbol)), exsymbol);
              	file_table->code_table[IC].code |= EX_SYM ;
              	IC++;
         	}
          	else
          	{ 
				/* label is not external */
              	sym = labAdd((&(file_table->symbolTable)), addrs2.opName);
              	file_table->code_table[IC].code = CODE_Sym;
              	file_table->code_table[IC].code |= (sym+LINENUM_INITIAL)<< ARE_SKIP;
              	IC++;
               	return true;
         	}
    	}
       	else /* if its not a label */
       	{ 
        	IC++;
        	return true;
     	}
  	} 
	return true;
}
