#include "dataStructure.h"

/*opcode type: 2 operators array*/
static opCode2 opCodeVal2Op[]= 
{ /* each opcode have its hashing methods for each operand */
    {0 ,"mov",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {1 ,"cmp",3,{IMMEDIATE,DIRECT,DIRECT_REG},3,{IMMEDIATE,DIRECT_REG,DIRECT}},
    {2 ,"add",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {3 ,"sub",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {6 ,"lea",1,{DIRECT},2,{DIRECT,DIRECT_REG}},

};
/*opcode type 1 operator array*/
static opCode1 opCodeVal1Op[] = 
{/* each opcode have its hashing methods*/
    {4 ,"not",2,{DIRECT,DIRECT_REG}},
    {5 ,"clr",2,{DIRECT,DIRECT_REG}},
    {7 ,"inc",2,{DIRECT,DIRECT_REG}},
    {8 ,"dec",2,{DIRECT,DIRECT_REG}},
    {9 ,"jmp",3,{DIRECT,JUMP,DIRECT_REG}},
    {10 ,"bne",3,{DIRECT,JUMP,DIRECT_REG}},
    {11 ,"red",2,{DIRECT,DIRECT_REG}},
    {12 ,"prn",4,{IMMEDIATE,DIRECT,DIRECT_REG}},
    {13 ,"jsr",3,{DIRECT,JUMP,DIRECT_REG}},
};
/*opcode type: 0 operators array*/
static opCode0 opCodeValZOp[] = 
{
    {14 ,"rts"},
    {15 ,"stop"},
};
/* a structure for searcing the instance of the word after the '.' operator */ 
static struct search_inst search_inst_table[] = 
{
    {"data", DATA_INST},
    {"string", STRING_INST},
    {"entry", ENTRY_INST},
    {"extern", EXTERN_INST},
    {NULL, NONE_INST}
};

static char registers[8][3] =
{
    "r0",
    "r1",
    "r2",
    "r3",
    "r4",
    "r5",
    "r6",
    "r7", 
};
/* freeing a node */
void free_symbol(symbol *sym)
{
    if (sym == NULL)
        return;

    else
    free(sym);
}

/* freeing the link list ,by order, step by step */ 
void del_symbol_table(symbol_table *table)
{
    symbol* node;
    symbol* prev;
    if (table == NULL || *table == NULL  )
        return;

    node = *table;
    prev = node;
    /* Go over all the symbols in the table */
    while (node != NULL)
    {
        prev = node;           
        node = node->next;
        free_symbol(prev);
    }
}

/* check if the symbol is on the symbol table, if not returns NULL */
symbol* find_symbol(symbol_table *table, char *name)
{	
    symbol* node;
    if (table == NULL || name == NULL || *table == NULL)
    {
        return NULL;
    }
    node = *table;
    while (node != NULL)
    { 
        if (!strcmp(node->name, name) ) 
        {/* if found, return the pointer */    
            return node;
        }
        node = node->next;
    }   
    return NULL; /* if not found, return NULL */
}

/* creating a node which represents a symbol 
using tp as a type and ad as an address. the name will be the name too */
symbol *create_symbol(char *name, sym_type tp, unsigned int ad)
{
    symbol *sym = (symbol*) malloc(sizeof(symbol));
    /* set the values */
    strncpy(sym->name, name,LINELEN);
    if (strchr(sym->name,'\n')) /* cutting the redundant \n at the end of the symbol */
    {
        *strchr(sym->name,'\n') = '\0';
    }
    sym->type = tp; /* updating symbol values */
    sym->address = ad;
    sym->next = NULL;
    return sym;
}

/* adding a node to the end of the linked list of the symbols */
void add_symbol(symbol_table *table, symbol *sym)
{
    symbol *node;
    /* if the table isn't initated, init the table */
    if (*table == NULL)
    {
        *table = sym;
        return;
    }
    node = *table;
    while (node->next != NULL)
    {
        if (node == sym) /* prevent nasty loops */
            return;
        node = node->next;
    }
    node->next = sym; /* add the symbol to the table */
}

/* returns the type of the operand*/
addrs_method addressType(char* word)
{
	int i;
	int count = 0; 
    if (*(word) == '#')
    {
    	
    	for(i = 1 ; i < strlen(word) ; i ++)
    	{	
    		if(!isspace(word[i]) && !isdigit(word[i]) && word[i] != '+' && word[i] != '-')
    		{
    			/* weve reached an illigal characterfor this operand */
    			return NONE_ADDRS;
    		}	
    		if (isdigit(word[i]))
    			{
    				/* after a digit in this operand , you can no longer accept characters as '+' or '-' but only digits and spaces. */
    				for(;i<strlen(word);i++)
    				{
    					if(!isspace(word[i]) && !isdigit(word[i]))
    					{
    						return NONE_ADDRS;
    					}
    				}
    			}
    		if (word[i] == '+' || word[i] == '-')
    		{
    		/* after '+' or '-' you can only accept a digit or a space
    		and also , you have to accept at least 1 digit. so in this check were doing that. */
    			i++; /* incementing i in order not to check the '+' or '-' operands again */
    			for(;i<strlen(word);i++)
    				{
    					if(!isspace(word[i]) && !isdigit(word[i]))
    					{
    						return NONE_ADDRS;
    					}
    					/* counting the digits. if theres no digis well return an error */
    					if (isdigit(word[i])) 
    						count++;
    				}
    			if(count == 0)
    				return NONE_ADDRS;
    		}    		  	    			
        }
        return IMMEDIATE;
    }
    /*checking for register*/
    if((*(word) == 'r' && atoi(word+1) >= 0 && atoi(word+1) <=7 && *(word+2)== '\0' )||((*(word+2)== '\n') && (*(word) == 'r') && atoi(word+1) >= 0 && atoi(word+1) <=7))
    {
        return DIRECT_REG;
    }
    if (*(word) == '(' && *(word+1) == '#')
    {
    	return JUMP;
    }
    /*checking for label*/
    else  
    if (isdigit(*(word))|| strlen(word) > LABELMAX)
    { 
    return NONE_ADDRS;
    }
    
        return DIRECT; 

}
/* using the structure searc_inst in order to find the instance of the word
after the '.' operand */
instruction findInst(char *str)
{
    search_inst *inst;

    /* Search the Instruction Type */
    for(inst = search_inst_table; inst->name_inst != NULL; inst++)
    {
        if(strcmp(str, inst->name_inst) == 0)
        {
            return inst->value_inst;
        }
    }
    /* The last String in the array is: inst->name_inst == NULL */
    return inst->value_inst; /* == NONE_INST (NULL) */
}

/* checks if the symbol is legal */ 
int CheckTheLabelName(char *labelName)
{    
    int i;
    /* check that the label name isnt too long */
	if(strlen(labelName) > LABELMAX)
	{
		return 0;
	}
	/* check that the label name starts with an alphabetic character */
	if(!isalpha(*(labelName)))
	{
		return 0;
	}
	/* check that the rest of the characters in the label are legal -> alphabetic or digits */
	for(i=0;labelName[i]!='\0';i++)
	{
		if((!isalpha(labelName[i])) && (!isdigit(labelName[i])))
		{
			return 0;
		}
	}
	/* check that its not an opcode name */
    for(i=0;i<(sizeof(opCodeVal2Op) / sizeof(struct opCode2));i++)
	{
        if (!strcmp(labelName,opCodeVal2Op[i].commandName))
        {
            return 0;
        }
    }
    /* check that its not an opcode name */
    for(i=0;i<(sizeof(opCodeVal1Op) / sizeof(struct opCode1));i++)
	{
        if (!strcmp(labelName,opCodeVal1Op[i].commandName))
        {
            return 0;
        }
    }
    /* check that its not an opcode name */
    for(i=0;i<(sizeof(opCodeValZOp) / sizeof(struct opCode0));i++)
	{
        if (!strcmp(labelName,opCodeValZOp[i].commandName))
        {
            return 0;
        }
    }
    /* check that its not a register name */
	for (i = 0 ;i < REG_NUMBER; i++)
	{
		if (!strcmp(labelName,registers[i]))
			{
                return 0;
			}
	}

    return 1; 
}
