/*
 *
 * define struct that will represent the macro linked list.
 * name: the name of the macro, statically allocated.
 * macro: pointer to dynamically allocated String that contain
 * the macro code, we adding the macro code lines dynamically 
 * for each line.
 * next: point to next macro in the list.
 */
struct macro
{
    char name[LINELEN];
    char *macro;
    struct macro *next;
}; 

/*
 * param:
 * char*
 * char***
 * char***
 * int*
 * int
 * int*
 * action:
 * saving the name of the macro
 */	
struct macro *saveName(char* buffer,struct macro **table,int* maci, int* mcrBool);
/*
 * param:
 * char*
 * char***
 * int*
 * int
 * int*
 * action:
 * saving the content of the macro
 */	
void saveCon(char* buffer,struct macro *entry, int* mcrBool);
/*
 * param:
 * char*
 * FILE*
 * FILE*
 * char**
 * char**
 * int*
 * action:
 * printing the macro contents instead ofthe macro names to the new file
 */			
void printing(char* buffer,struct macro **table, FILE *fpNew , int *maci);
/*
 * param:
 * FILE *
 * FILE*
 * action: 
 * converting the macro names to the macro content
 */
void preassembler(FILE *fp, FILE *fpNew)	;
