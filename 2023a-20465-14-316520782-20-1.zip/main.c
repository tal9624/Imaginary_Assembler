#include <unistd.h>
#include "dataStructure.h"
#include "first_pass.h"
#include "second_pass.h"
#include "preassembler.h"
#include "output.h"
int IC = 0, DC = 0;  /* global intergers */
bool assembler(char *name); /* func prototyp */

/* main function, first the preassembler pass and then another 2 passes on the file */
int main( int argc, char *argv[])
{	
	int arg_i; /* argument index*/
	int numberOfArguments = argc;
	FILE *fpNew = NULL;
	FILE *fp = NULL; /* file pointer */	
	char kelet[FILE_NAME_MAX];
	char afterMac[FILE_NAME_MAX];
	/* check for a right number of arguments */
	if (numberOfArguments == 1) 
	{
		printf("number of arguments should be at least 2,\n");
		printf("1 for the program name,\nand the others for  the file name.\n");
		return -1;
	}
	for (arg_i = 1 ;arg_i < numberOfArguments ;arg_i++ )
	{
		/* opening the after macro file */
		strcpy(kelet,argv[arg_i]);
		strcat(kelet,".as");
		strcpy(afterMac,argv[arg_i]);
		strcat(afterMac,".am");

		fp = fopen(kelet, "r");	

		if (fp == NULL)
		{	
			printf("ERROR:reading failed\n");
        	return -1;   
		} 

		fpNew = fopen (afterMac, "w");

		if (fpNew == NULL)
		{	
			printf("ERROR:cant open a file\n");
        	return -1;   
		} 	
	
		preassembler(fp,fpNew); /*preassembler*/	

        fclose(fp);
        fclose(fpNew);

		assembler(afterMac);

	}/* end of for loop */
	return 0;	
}/* end of main function */

/* the assembler that goes for the 2 passes */
bool assembler(char *name)
{
    bool is_success = true;
    /* boolean for present : if it has succeeded so far */
    /* assembly src namefile */ 
    /* assembly src file */
    FILE* fp;   
    /* to check the line that is limited to a maximum of LINELEN characters, with 2 more places for '\n' and '\0' */
    char current_line[LINELEN + 2]; 
    /* contains information on the current line */
    info_of_line line_info;
    /* the tables needed to process the file */
    pross_table file_tables;
    /* reset the IC and DC */
	IC = 0, DC = 0;
    /* Reset all the Pointers */
    memset(&(file_tables), 0, sizeof(pross_table));
    fp = fopen(name, "r");
    if(fp == NULL)
    {
        printf("ERROR:error opening file");
        return false;
    }
    /* Go over all the lines in the source file */

    for(line_info.line_num = 1, line_info.file_name = name; 
        (line_info.text = fgets(current_line, LINELEN , fp)) != NULL; line_info.line_num++) 
    {
        is_success = first_pass(line_info, &file_tables) && is_success;
    } /* end of for loop*/
    
    IC = 0;
    rewind(fp); /* taking the file pointer to the beginning of the file for the second pass */
   
	if (is_success)
	{ 
    	for(line_info.line_num = 1, line_info.file_name = name; 
        	(line_info.text = fgets(current_line, LINELEN , fp)) != NULL; line_info.line_num ++) 
        	{       
        		is_success = second_pass(line_info, &file_tables) && is_success;
        	}
	}

	if(is_success)
	{ 
	    output(&file_tables, IC, DC, name); 
	}

       
    del_symbol_table(&(file_tables.symbolTable));
    del_symbol_table(&(file_tables.ExSymbol));
    
	return is_success;    
} /* end of assembler function */


