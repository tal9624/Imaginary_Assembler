#include "dataStructure.h"
#include "preassembler.h"



/*
 * This function get's pointer to macro table and name of macro,
 * we Search in the linked list table for macro that will match to
 * the given name, if we found we return the pointer to the macro code,
 * else we return null.
 */
char *get_macro(struct macro *entry, char *name)
{
    /* if the table isn't initalized yet */
    if (entry == NULL)
        return NULL;

    /* search in the all linked list */
    while (entry != NULL)
    {
        /* if found */
        if (!strcmp(entry->name, name))
            return entry->macro; /* return the pointer */
        /* else, go to the next one */
        entry = entry->next;
    }

    /* if didn't found */
    return NULL;
}

/*
 * This function add macro entry to the macro table (linked list).
 */
void add_macro(struct macro **table, struct macro *entry)
{
    struct macro *node; /* temporarly pointer */

    /* if the table didn't initiated yes */
    if (*table == NULL)
    {
        /* initiated the table and exit */
        *table = entry;
        return;
    }

    node = *table;

    /* search for the last variable */
    while (node->next != NULL)
        node = node->next;

    /* add to the last variable */
    node->next = entry;
}

/*
 * This function release the memory resource the was used by the table.
 */
void delete_macro(struct macro **table)
{
    struct macro *prev, *node;

    /* if the table isn't initiated yet, there's nothing to do */
    if (*table == NULL)
        return;

    node = *table;
    prev = node;

    while (node != NULL)
    {
        /* save the previous and continue to the next */
        prev = node;
        node = node->next;

        /* free the macro code */
        free(prev->macro);
        /* free the current node */
        free(prev);
    }
}


/* this function save the names of the macros in a dynamic array
for each name well reallocate another space for it
well expend also the contents array for each name well define */
struct macro *saveName(char* buffer,struct macro **table,int* maci, int* mcrBool) 
{	
    /* allocate new macro entry for the table */
	struct macro *current = malloc(sizeof(struct macro));	
    /* initalized it with 0 value */
    current->macro = NULL;
    current->next = NULL;
	
	
    /* Mark the macro block has True = Active */
	*mcrBool = 1;

	(*maci)++; /* representing the macro index */
	/* extending the array for each macro */
	/*printString(buffer);*/
	
    /* Go to the macro name */
    SKIP_WHITESPACE(buffer);

    /* in case of \n, "delete" it */
    if (strchr(buffer, '\n'))
    {
        *strchr(buffer,'\n') = '\0';
    }

    /* copy the name to the macro entry in the table */
    strcpy(current->name, buffer);

    /* add the macro to the table */
	add_macro(table,current);
    /* return the address of the entry for the function */
	return current;	
} /* end of function */

/* this function save the contents of the macros in a dynamic array
for each content line we'll reallocate another space for it,
as the size of the line*/
void saveCon(char* buffer,struct macro *entry, int* mcrBool)
{
    /* Check if this line ends the macro block */
	if(strncmp(buffer, "endmcr", 6)) /* not endmcr */
	{
        /* if not, add the macro block line to the macro code block */

        /* if the macro String hasn't initalized yet */
        if (!entry->macro)
        {
            /* initaliz it */
            entry->macro = malloc(strlen(buffer) + 1);
            /* Mark the strings as null terminated in the beginning! */
            entry->macro[0] = '\0';
        }
        else
        {
            /* else, reallocate more memory enough for the macro block */
		    entry->macro = realloc(entry->macro,strlen(entry->macro) + (strlen(buffer)+1));
        }
        /* add the macro line block to the macro code block */
		strcat(entry->macro,buffer);	 
	}
    /* if yes, mark the macro block as False : ends */
	else
	{
		*mcrBool = 0;
	}
}/* end of fuction */

/* 
 * adding the line to the file. 
 * in case of macro block name, add the macro block code.
 */
void printing(char* buffer,struct macro **table, FILE *fpNew , int *maci)	
{	
    /* Save the first word in the line  */
	char firstRead[LINELEN];
    
    /* Go to the next word in the line */
	SKIP_WHITESPACE(buffer);	

    /* save the first word from the line to the buffer */
	sscanf(buffer,"%s",firstRead); 

	/* Checking if there's \n in the word for rare cases */
	if (strchr(firstRead,'\n'))
	{
        /* if found, terminate it */
		*strchr(firstRead,'\n') = '\0';
	}	
	
    /* check if the first word represent macro block name */
	if(get_macro(*table,firstRead))
	{	
        /* if it is, add the macro code block to the file instead of the current line */
		fputs(get_macro(*table,firstRead),fpNew); 
	}	
	
    /* else, it's regular code line */
    else 
	{ 
        /* putting the word to the new file */
	    fputs(buffer,fpNew);
	}		
} /* end of fuction */		
/* this function is the main algorithm of the macro stage
its using savename, savecon, and printing. at the end , 
it frees the pointers */
void preassembler(FILE *fp, FILE *fpNew)		
{
    /* buffer save each line in the file */
	char *buffer = (char*)malloc((LINELEN)*sizeof(char)); 
    /* save the allocated line buffer */
    char *curr = buffer;
    /* 
     * represent boolean value if we in macro block:
     * 0 means not in macro block.
     * otherwise we inside macro block 
     */
	int mcrBool = 0;
    /* save the current macro code block */
	struct macro *current;
	int maci = -1; /* macro  index */	
    /* Initalize pointer to the macro table */
	struct macro *table = NULL;
	
	/* saving macros name in macNames array of strings
	and also saving macro contents in maccontencts array of strings */ 
    /* Getting each line of the file */
	while (fgets(buffer,LINELEN - 2, fp))  
	{ 
        /* go to the next word */
	    SKIP_WHITESPACE(buffer);

        /* Checking if we starting to define macro */
		if (strlen(buffer) >= 3 && buffer[0] == 'm' && buffer[1] == 'c' && buffer[2] == 'r' && mcrBool == 0) 
		{
			/*saving the name of the macro to the table */
			current = saveName(buffer + 3,&table, &maci, &mcrBool);	
		}
		/* else, check if we already inside macro block */
		else if ( mcrBool == 1) 
		{	/* add = save the contact of the macro */
			saveCon(buffer,current, &mcrBool);	 
		}
        /* else, it's regular line that might have macro name */
        else
		{	/* print to the new file */
			printing(buffer, &table, fpNew ,&maci); 
		}			

        buffer = curr; /* update buffer to point to the allocated memory */
	} /* end of while loop */
	/* freeing the pointers step by step */
    free(curr);
	delete_macro(&table);
	/* closing the files */
}/* end of fuction */	

