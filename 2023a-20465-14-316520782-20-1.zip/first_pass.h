/*
 * param:
 * info_of_line
 * char*
 * return:
 * boolean value( true or false )
 */
bool blankCheck(info_of_line line_info,char * word);
/* 
 * param:
 * info_of_line
 * pross_table*
 * return:
 * boolean value ( true or false ) 
 */
bool first_pass(info_of_line line_info, pross_table *file_tables);
/*
 * param:
 * instruction
 * info_of_line
 * symbol_table*
 * return:
 * boolean value(true or false)
 */
bool checkExternAndEntry(instruction current_inst,info_of_line line_info, symbol_table *table);
/*
 * param:
 * info_of_line
 * instruction
 * table*
 * return:
 * boolean value(true or false)
 */
bool checkDataAndStr(info_of_line line_info,instruction current_inst ,table* dataTable);
/*
 * param:
 * info_of_line
 * table*
 * return:
 * integer( a complete number )
 */
int readStr(info_of_line line_info,table* dataTable);
/*
 * param:
 * info_of_line
 * table*
 * return:
 * integer( a complete number )
 */
int readData(info_of_line line_info,table* dataTable);
/* 
 * param:
 * info_of_line
 * char [LINELEN]
 * table*
 * return:
 * boolean value ( true or false )
 */
bool codePross(info_of_line line_info, char word[LINELEN], table *code_table);
/*
 * param:
 * info_of_line
 * table *
 * integer
 * return:
 * boolean value ( true or false )
 */
bool searchOp2(info_of_line line_info, table *code_table, int i);
/*
 * param:
 * info_of_line
 * table*
 * integer
 * return:
 * boolean value ( true or false )
 */
bool searchOp1(info_of_line line_info, table *code_table, int i);
/*
 * param:
 * value
 * int
 * table 
 * action:
 * coding the 1 operator instructions
 */  
void kidud1(value addrs2,int index, table *code_table);
/*
 * param:
 * value
 * value
 * value
 * int
 * table
 * action:
 * coding the jump hashing method for 1 operand instructions
 */ 
void kidud_jump(value addrs1,value addrs2,value addrs3,int index,  table *code_table);
/*
 * param:
 * value
 * value
 * int
 * table*
 * action:
 * coding the 2 operator instructions
 */ 
void kidud2 (value addrs1,value addrs2,int index,  table *code_table);
/*
 * param:
 * char*
 * char const*
 * return:
 * char*
 */
char *strtok_single (char * str, char const * delims);

