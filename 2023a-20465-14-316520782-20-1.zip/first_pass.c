#include "dataStructure.h"
#include "first_pass.h"
/*opcode type: 2 operators array*/
static opCode2 opCodeVal2Op[]= 
{
    {0 ,"mov",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {1 ,"cmp",3,{IMMEDIATE,DIRECT,DIRECT_REG},3,{IMMEDIATE,DIRECT,DIRECT_REG}},
    {2 ,"add",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {3 ,"sub",3,{IMMEDIATE,DIRECT,DIRECT_REG},2,{DIRECT,DIRECT_REG}},
    {6 ,"lea",1,{DIRECT},2,{DIRECT,DIRECT_REG}},

};

/*opcode type 1 operator array*/
static opCode1 opCodeVal1Op[] = 
{
    {4 ,"not",2,{DIRECT,DIRECT_REG}},
    {5 ,"clr",2,{DIRECT,DIRECT_REG}},
    {7 ,"inc",2,{DIRECT,DIRECT_REG}},
    {8 ,"dec",2,{DIRECT,DIRECT_REG}},
    {9 ,"jmp",3,{DIRECT,JUMP,DIRECT_REG}},
    {10 ,"bne",3,{DIRECT,JUMP,DIRECT_REG}},
    {11 ,"red",2,{DIRECT,DIRECT_REG}},
    {12 ,"prn",4,{IMMEDIATE,DIRECT,DIRECT_REG}},
    {13 ,"jsr",3,{DIRECT,JUMP,DIRECT_REG}},
};
/*opcode type: 0 operators array*/
static opCode0 opCodeValZOp[] = 
{
    {14 ,"rts"},
    {15 ,"stop"},
};

/** Register r0-r7 type */
static char registers[8][3] =
{
    "r0",
    "r1",
    "r2",
    "r3",
    "r4",
    "r5",
    "r6",
    "r7",
  
};

/*a function similiar to strtok but this one can recognize when no data appears between two token seperators. strtok_single makes use of strpbrk (char const* src, const char* delims) which will return a pointer to the first occurrence of any character in delims that is found in the null-terminated string src.
If no matching character is found the function will return NULL. */
char *strtok_single (char * str, char const * delims)
{
  static char  * src = NULL;
  char  *  p,  * ret = 0;

  if (str != NULL)
    src = str;

  if (src == NULL)
    return NULL;

  if ((p = strpbrk (src, delims)) != NULL) 
  {
    *p  = 0;
    ret = src;
    src = ++p;

  } 
  else if (*src) 
  {
    ret = src;
    src = NULL;
  }

  return ret;
} /* end of function */

/* checking for blank lines */
bool blankCheck(info_of_line line_info,char * word)
{
	int i;
	for( i = 0 ; i< strlen(line_info.text) ; i++)
        {
        if ( isspace(word[i] )) /* check for each char that he is a space */
       	    continue;
        else
        	break;
        }/* end of for loop */
        if (i == strlen(line_info.text)-1)
        {
        	return true;
        }
        return false;
}/* end of function */

/* a main procedure the first pass!
will go through the line sent from the file and determine 
for each word if its a label , a register , an instruction ..
and will send it to the right functin to keep the coding process */
bool first_pass(info_of_line line_info, pross_table *file_tables)
{	
    char word[LINELEN]; /* checking each word of the line with this char array */
    bool flagForLabel = false; /* well turn it on if well find a label */
    char labelName[LINELEN];
    symbol *sym; 
    bool code;
    instruction current_inst;
    SKIP_WHITESPACE(line_info.text);/*go to the first place in the line with char*/   
	while((sscanf(line_info.text, "%s", word)) != '\n')
    {
        /*if blank line or comment line. The line is OK */     
		if (blankCheck(line_info,word))
		{
     	   return true;/* when line contains only spaces return true */
    	}      
        if( word[0] == ';' )
        {
           return true;/* when line starts with a ';' return true */
        }
        /* promotes 'line_info.text' to the next word */
        line_info.text += (strlen(word));
        SKIP_WHITESPACE(line_info.text);		
		if((*line_info.text) == ':' ) /*a label cant be an empty word */
        {
           	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        	printf("ERROR:the label name is wrong, return\n");   
            return false;
        }                
        /***************************************************************************
        find label
        ***************************************************************************/        
        if ((*(word + (strlen(word) - 1)) == ':')) /*.if its a label */
        {
            memcpy(labelName, word, strlen(word) - 1);/* labelname now have the label name */ 
            *(labelName + strlen(word) - 1) = 0;
			
            if(!CheckTheLabelName(labelName))
            {
          		printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        		printf("ERROR:the label name is wrong, return\n");   
                return false;
            }
            else
            {
                flagForLabel = true; 
                /* promotes 'line_info.text' to the next unread & not white character */
                continue;
            }
        }        
        /***************************************************************************
        find inst
        ***************************************************************************/       
        if(*word == '.')
        { 
            current_inst = findInst(word+1); /* now current_inst have the name of the inst */
            if(current_inst == ENTRY_INST || current_inst == EXTERN_INST)
            {
                return checkExternAndEntry(current_inst,line_info,&(file_tables->symbolTable));
            }
            else if ((current_inst != NONE_INST)) /* if Data or str */
            {
 
                if(flagForLabel)
                {	/*searching for the label name */
                    if(find_symbol(&(file_tables->symbolTable), labelName) != NULL)
                    { /* find the label name */
          				printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        				printf("ERROR:the label name has already been defined");
        				printf(" and cant be declared twice\n"); 
                            return false;
                    }
                    else
                    {   /* creating a new label */                 
                        sym = create_symbol(labelName, DATA_Sym, DC+IC);
                        add_symbol(&(file_tables->symbolTable), sym);  
                    }
                }
                return checkDataAndStr(line_info, current_inst ,(file_tables->data_table));
            }                  
            else 
            {
            	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        		printf("ERROR:%c operator but no appropriate command\n",'.');
            	return false;
            }
        }
        /*
        ***************************************************************************
        code process
        ***************************************************************************
        */
        else 
        {
            if(flagForLabel)
            {/*searching for the label name */
            	if(find_symbol(&(file_tables->symbolTable), labelName) != NULL)
            	{
                	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        			printf("ERROR:the label name has already been defined");
        			printf(" and cant be declared twice\n");    
                    return false;
                }
                else
                {
                    sym = create_symbol(labelName, CODE_Sym, DC+IC);
                    add_symbol(&(file_tables->symbolTable), sym);
                }
            }
            /*opcode found ,  start coding */
            code = codePross(line_info, word, (file_tables->code_table));
            return code;
        }
    }/* end of while loop */
	return true;
}/* end of function */

/*on the first pass, if the label is entry were returning true; 
if its extern will check the label name, and create a symbol if there are no errors.
the last " return false " is unreachable because we covered all of the possible cases*/
bool checkExternAndEntry(instruction current_inst,info_of_line line_info, symbol_table *table)
{
    char word[LINELEN];
    symbol *sym;
   	int count = 0;    
	if (current_inst == EXTERN_INST ||current_inst == ENTRY_INST)
    {
		if (blankCheck(line_info,word))
		{	/* empty label */
     	   	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        	printf("ERROR:external or enternal without symbol\n");           
            return false;
    	}

		else
		{
			while(sscanf(line_info.text, "%s", word) != '\n')
			{
        		/*check the label name after external or enternal*/
				if (blankCheck(line_info,word) && count == 1)
				{ 
					/* end of line and only one word after ".extern" || ".entern " */
     	   			return true;
    			}
				else
				{ 
            		line_info.text += (strlen(word));
            		SKIP_WHITESPACE(line_info.text);		
					count++;
        			if (count >= 2)
        			{ 
						/* more then one label in external or enetrnal  */
        				printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        				printf("ERROR:too many symbols in the external\nor enternal\n");    				           
            			return false;
        			}
        			else
        			{
                 
           				if(!CheckTheLabelName(word))
           				{ 
							/* the label is illegal */
           		     		printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
               		 		printf("ERROR:the label name is illegal\n");
               		 		return false;
         	      		}

            			else
            			{
            				if (current_inst == EXTERN_INST)
            				{
							/* if the label doesnt exists yet and extern */
                				if(!find_symbol(table, word))
                				{	
								/*addind the label */
                    				sym = create_symbol(word, EXTERNAL_Sym, 0);
                    				add_symbol(table, sym);
                				}

                				else 
                				{
                					printf("File->%s:",line_info.file_name);
                					printf("line->%ld:",line_info.line_num);
                					printf("ERROR:the label already exists\n"); 
                					return false; 
                				}
                			}
            			}
         			} 
        		}
			}/* end of while loop */
		}
	}
    printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
    printf("ERROR:unreachable ERROR\n");
	return false;

}/* end of function */

/*check if the current word sent to the func is a data or a string */
bool checkDataAndStr(info_of_line line_info,instruction current_inst ,table* dataTable)
{
    int temp;
    /*if the symbol is data */
    if (current_inst == DATA_INST)
    {
        if((temp = readData(line_info,dataTable)) > 0)
        {	
			/*updating data table in order */
            DC += temp;
            
        }
        return true; 
    }
    /*if the symbol is string*/
    else if (current_inst == STRING_INST)
    {
        if((temp = readStr(line_info,dataTable)) > 0)
        {  /*updating data table in order */
            DC += temp;             
        }
        return true; 
    }

    printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
    printf("ERROR: Unreachable ERROR");
    return false; 

}/* end of function */


/*coding the string to the data table, and checking for any faulties */
int readStr(info_of_line line_info,table* dataTable)
{	
	int tempDC = 0;
	int ascii;

    if (*(line_info.text) =='"')
  	{	
		/* it starts with a '"' so its ok */
        line_info.text++;
  		while(*(line_info.text) != '"' && *(line_info.text) != '\n' )
  		{	
			/* isprint checks if the char is on the ascii table */
  			if (isprint(*(line_info.text)))
  			{	
				/* the char is on the askii table, coding it */
                ascii = *(line_info.text);
                dataTable[DC+tempDC].code = ascii;
                dataTable[DC+tempDC].address = DC+tempDC;
                tempDC++; 
                line_info.text++;
  			}
	
  			else
            {
				/* The input String on line is not on the ascii table */
             	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
             	printf("ERROR: The input String on line is not on the ascii table\n");         
  				return 0;
            }
  		}  /* end of while loop */	
	
  		if (*(line_info.text) == '"')
  		{	
			/* it ends with a '"' so its ok, coding the last line as 0 and returning */
  			dataTable[DC+tempDC].code = 0; 
  			dataTable[DC+tempDC].address = DC+tempDC;
  			tempDC++;
  			/* now well check for redundant characters after the end of the string */
  			line_info.text++;
  			SKIP_WHITESPACE(line_info.text);
  			if(*(line_info.text) != '\n')
  			{
  				printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
             	printf("ERROR: redundant characters\n"); 
  				return false;
  			}
  			return tempDC;
  		} 

  		else
  		{
			/* it doesnt ends with a '"' */
  			printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
  			printf("ERROR: The input String is Wrong because it doesnt end with a %c!\n",'"');
  			return 0;
  		}	
  	}	
	/* it doesnt starts with a '"' */
  	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
  	printf("ERROR: The input String is Wrong because it doesnt start with a %c!\n",'"');
    return 0;

}/* end of function */


/*coding the data to the data table, and checking for any faulties */
int readData(info_of_line line_info,table* dataTable)
{
    int tempDC = 0;
    char* curNumStr; /* the current number string */
    int curNum;
    int count=0;
    int i;
    int len = strlen(line_info.text);

    for (  ;isspace(*(line_info.text)+len) ;len--); /* end of this loop */

    if (',' == *(line_info.text)+len)
    {
      	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
      	printf("ERROR: The input String is Wrong because it have an unnecessary");
      	printf(" %c in the end of line\n",',');
    	return 0;
    }
	
    curNumStr = strtok_single(line_info.text, ","); 

    while (curNumStr != NULL)
    {	/*checking for redundant plus or minus operands */
    	for(i=0; i<strlen(curNumStr) ; i++)
    	{
    		if ( count > 1 )
    		{
    			printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
      			printf("ERROR: redundant plus or minus operands\n");
      			return 0;
    		}
    		if ( curNumStr[i] == '+' || curNumStr[i] == '-' )
    		{
    			count++;
    		}
    		
    	}/* end of loop */
    	/* check for illegal chars in the current number string */
    	for ( i=0 ; i< strlen(curNumStr) ; i ++)
    	{
    		/* were looking for a digit first in order to detect the error */
    		if ( isdigit(curNumStr[i]))
    		{
    			i++;
    			for(; i< strlen(curNumStr) ; i++)
    			if ( !isdigit(curNumStr[i]) && !isspace(curNumStr[i]))
    			{
    				printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
      				printf("ERROR: illegal operands after the digit\n");
      				return 0;
    			}
    		}
    	}/* end ofloop */
    	
    	if(curNumStr[0] == '\0')
    	{
    		printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
      		printf("ERROR: 2 commas without a number between\n");
      		return 0;
    	}		
		/*extreme case we hvae to take care of, because atoi(curNumStr=0) is also 0 */
    	if (!strcmp(curNumStr,"0")) 
    	{	/*coding an 0 */
    		dataTable[DC+tempDC].code = 0;
        	dataTable[DC+tempDC].address = DC+tempDC;
    		tempDC++;
   		}
		
    	else
    	{
    		curNum = atoi(curNumStr);/*converting the char to a string */
    		
			if (curNum == 0) 
    		{ /* now we know for sure its not a digit */
    			printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
    			printf("ERROR: The input String is Wrong because it");
    			printf("contains a nondigit operand\n");
    			return 0;
    		}
	
    		else
    		{ 
				/* coding a ususal digit ( not a '0' ) */
    			dataTable[DC+tempDC].code = curNum;
            	dataTable[DC+tempDC].address = DC+tempDC;
    			tempDC++;
   	 		}
    	}

    	curNumStr = strtok_single(NULL, ",");

    }/* end of while loop */

    return tempDC;

}/* end of function */

/* finding the instruction method , and then sending it to the coding function , or in case of 1 operand only ,coding the instructions ( such as stop .. etc ) to the instruction table */
bool codePross(info_of_line line_info, char word[LINELEN], table *code_table)
{   

	int i;
    int commaCount = 0; /* comma counter */
    char* commaCheck;

    /* check for 2 operands */
    for(i=0;i<(sizeof(opCodeVal2Op) / sizeof(struct opCode2));i++)
    {
        if (!strcmp(word,opCodeVal2Op[i].commandName))
        {/* found  a 2 operand opcode */       
            for( commaCheck = line_info.text ; *(commaCheck) != '\0' ; commaCheck++)
            {/* counting commas */
                 if (*(commaCheck) == ',')
                 commaCount++;
            }
            if (commaCount != 1){
            	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
               	printf("ERROR: The input String is Wrong because it ");
               	printf("have a comma count different then 1\n");
                return false;
            }
            else
            {
                return searchOp2(line_info, (code_table), i);				
        	}
		}
    }/* end of outer for loop */

    /* check for 1 operand */
    for(i=0;i<(sizeof(opCodeVal1Op) / sizeof(struct opCode1));i++)
    {
        if (!strcmp(word,opCodeVal1Op[i].commandName))
        {       
       	    return searchOp1(line_info, (code_table), i);
        }
    } /* end of outer for loop */ 
 
    /* zero operator check */
    for(i=0;i<(sizeof(opCodeValZOp) / sizeof(struct opCode0));i++)
    {
        if (!strcmp(word,opCodeValZOp[i].commandName)){
            code_table[IC].address = IC;
            code_table[IC].code |= (opCodeValZOp[i].commandNumber)<<OPCODE_SKIP;
            IC++;
            SKIP_WHITESPACE(line_info.text);
            /*check for redundant characters */
            if (strlen(line_info.text)>1)
            {
            	printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
                printf("ERROR: redundant characters\n");
                return false;
       	    }
            return true;
            }
    }/* end of for loop */
        printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        printf("ERROR: The input String is Wrong because of a nonexisting opcode\n");
        return false;
}/* end of function */

/*this function search for the operands after the 1 operand instruction found.
if found , without any ERRORS, will send it to the kidud1 funcion to code it */
bool searchOp1(info_of_line line_info, table *code_table, int i)
{
    int orgTokLen; /* the original token length. used to find redundant characters */
	int j;
	bool found = false;
    char* tok;
	value addrs1; /* addrs1,2 and 3 will represent the operands of the opcode */
    value addrs2;
    value addrs3;
    addrs_method address;

    /*important initialization because if the hashing method wont be found on the 
    SEARCHING LOOP , well stay with this value and return an ERROR */ 
    addrs1.adr = NONE_ADDRS;
    addrs2.adr = NONE_ADDRS;
    addrs3.adr = NONE_ADDRS;
	SKIP_WHITESPACE(line_info.text);
	if (*(line_info.text) == '\n')
	{
		printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        printf("ERROR: The input operand cant be empty!\n");
        return false;	
	}	
	address = addressType(line_info.text);   
    /* SEARCHING LOOP*/ 
    for(j=0;j < opCodeVal1Op[i].opDestinLen ;j++)
    {
        if (address == opCodeVal1Op[i].opDestination[j])
        {
            found = true; 
            addrs2.adr = address;
         	addrs2.opName = line_info.text;        		
        }
    }/* end of inside loop */

    if ( found == false ) /* equivalent to asking if addrs2.adr == NONE_VALUE*/
     {	
        printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
        printf("ERROR: The input String is Wrong because of ");
        printf("illegal operand types\n");
        return false;
     }
     if (strchr(addrs2.opName,'\n'))
     {
        *strchr(addrs2.opName,'\n') = '\0';
     }
          
     if (!strcmp(opCodeVal1Op[i].commandName,"jmp") || !strcmp(opCodeVal1Op[i].commandName,"jsr") || !strcmp(opCodeVal1Op[i].commandName,"bne"))
     {/* it may be a jumping method */
           
        if(addrs2.adr == DIRECT)
        {  
            /* a label*/
            for( ;(*(line_info.text) != '\0') && (*(line_info.text) != '(') ;line_info.text++);/*going to the end of the label, end of this loop */
            if (*(line_info.text) == '\0')
            {
                kidud1(addrs2,i,(code_table));
                return true;
            }
            
            else if (*(line_info.text) == '(') 
            {	
                /*now we know we have 2 more operands */
                found = false; 
                addrs3.adr=JUMP;
                tok = strtok((line_info.text+1), ",");

                while (tok != NULL)
                {
				    /*using found  boolean value to get from the first operand to the second*/
                    if (!found)
                    {      
                        address = addressType(tok);
                        if((address != JUMP) && (address != NONE_ADDRS))
                        {
                            found = true; 
                            addrs1.adr = address;
                            addrs1.opName = tok;   
                        }
                    }

                    else
                    {	
                        orgTokLen = strlen(tok);
             			if (strchr(tok,')'))
                		{                				
                		    *strchr(tok,')') = '\0';               				
                		}   
                             /* in the next line theres a check for redundant characters 										after the opcode */
                		if (orgTokLen - 1 != strlen(tok))
                		{	
                			for ( i = strlen(tok)+1 ;i<orgTokLen ; i++)
                			{
                				/*check if the redundant cheacaters are blankspaces , if they are , this is not an ERROR */
                				if (!isspace(tok[i]))
                				{ 
                					printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
               			    		printf("ERROR: redundant characters\n");
                					return false;
                				}
							}                				
            			    
       	    			}                			
                        address = addressType(tok);
                   
                        if((address != JUMP) && (address != NONE_ADDRS)) 
                        {             
                            addrs2.adr = address;
                            addrs2.opName = tok;       
                        }
                    }                      
                    tok = strtok(NULL, ",");   
             
                }/* end of while loop */
                
                /* if we didnt find a legal hashing method */
                if (addrs1.adr == NONE_ADDRS || addrs2.adr == NONE_ADDRS)
                {
                    printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
                    printf("ERROR: The input String is Wrong because of ");
                    printf("illegal hashing method\n");
                    return false;
                }
                           
                else /* if operands are legal */
                {	
                    kidud_jump(addrs1,addrs2,addrs3,i,(code_table)); 
                    return true;
                }
            }   
        }
    }
    if (found)
    { 
        /* after we checked the option it needs hashing number 2 , we can be calm and go 				  to kidud1 for all of the other options of the first operand */
        kidud1(addrs2,i,(code_table));
        return true; 
    }
    return true;

} /* end of functions */

/* coding the operators of 1 operator instruction type to the instructions table */    
void kidud1(value addrs2,int index, table *code_table)
{
	int i;
	/*coding the opcode*/
    code_table[IC].address = IC;
    code_table[IC].code |= (opCodeVal1Op[index].commandNumber)<<OPCODE_SKIP;
    code_table[IC].code |= (addrs2.adr<<ARE_SKIP);
    IC++;

   	if (addrs2.adr == IMMEDIATE) /* if its the first hashing method */
	{
        code_table[IC].address = IC;
	    code_table[IC].code |= atoi(addrs2.opName+1)<<ARE_SKIP; 
	    IC++;
	}

	else if (addrs2.adr == DIRECT)/* if its the second hashing method */
	{
	    /*not coding. will be coded on the next pass */
        code_table[IC].address = IC;
	    IC++;
	}
	else if (addrs2.adr == DIRECT_REG)/* if its the forth hashing method */
	{
	    /*finding the register number and coding according to it */ 
	    for (i = 0 ;i < REG_NUMBER; i++)
		    {
		    if (!strcmp(addrs2.opName,registers[i]))
			    {
                    code_table[IC].address = IC;
				    code_table[IC].code |= (i<<SOURCE_REG_SKIP);
			    }
		    } /* end of for loop */ 
	    IC++;
	}
}	/* end of function */


/* coding the operators of jump operator instruction type to the instructions table */ 
void kidud_jump(value addrs1,value addrs2,value addrs3,int index,  table *code_table)
{
    int i =0;
    bool regfound = false; /* check if work without it , if does , delete*/
    /*coding opcode */
    code_table[IC].address = IC;    
	code_table[IC].code |= ((opCodeVal1Op[index].commandNumber)<<OPCODE_SKIP);
    code_table[IC].code |= (addrs3.adr<<ARE_SKIP);
	code_table[IC].code |= (addrs1.adr<<PARAM_TWO_HASH);
	code_table[IC].code |= (addrs2.adr<<PARAM_ONE_HASH);
    IC++;
    code_table[IC].address = IC; 
    IC++; /* anotherprogress cause of the label */

    if ( addrs1.adr == DIRECT_REG && addrs2.adr == DIRECT_REG ) /* check for params */ 
	{ 
        code_table[IC].address = IC;  
        /*finding the register number and coding according to it */ 				
		for ( i = 0 ;i < REG_NUMBER && (!regfound); i++)
		{
		    if (!strcmp(addrs1.opName,registers[i]))
			    { 
				    code_table[IC].code |= (i<<SOURCE_REG_SKIP);
				    regfound=true;
			    }
		    }
		regfound = false;
		/*finding the register number and coding according to it */ 
		for ( i = 0 ;i < REG_NUMBER && (!regfound); i++)
		{
			if (!strcmp(addrs2.opName,registers[i]))
			{ 
				code_table[IC].code |= (i<<ARE_SKIP);
				regfound=true;
				IC++;
			}
		}
		return;
	}
    if (addrs1.adr == IMMEDIATE) /* if its the first hashing method */
	{
        code_table[IC].address = IC;
	    code_table[IC].code |= atoi(addrs1.opName+1)<<ARE_SKIP; /* twos complement */ 
	    IC++;
	}
	else if (addrs1.adr == DIRECT) /* if its the second hashing method */
	{
	    /*not coding. will be coded on the next pass */
	    code_table[IC].address = IC;
	    IC++;
	}
	else if (addrs1.adr == DIRECT_REG) /* if its the forth hashing method */
	{
	    /*finding the register number and coding according to it */ 
	    for ( i = 0 ;i < REG_NUMBER && (!regfound); i++)
		{
		    if (!strcmp(addrs1.opName,registers[i]))
			{
                code_table[IC].address = IC;
				code_table[IC].code |= (i<<SOURCE_REG_SKIP);
				regfound=true;
                IC++;
			}
		}
	}
	if (addrs2.adr == IMMEDIATE)/* if its the first hashing method */
	{
        code_table[IC].address = IC;
	    code_table[IC].code |= atoi(addrs2.opName+1)<<ARE_SKIP; /* twos complement */ 
	    IC++;
	}
	else if (addrs2.adr == DIRECT)/* if its the second hashing method */
	{
	    /*not coding. will be coded on the next pass */
        code_table[IC].address = IC;
	    IC++;
	}
	else if (addrs2.adr == DIRECT_REG)/* if its the forth hashing method */
	{
	/*finding the register number and coding according to it */ 
	    for ( i = 0 ;i < REG_NUMBER ; i++)
	    {
		    if (!strcmp(addrs2.opName, registers[i]))
			    {
                    code_table[IC].address = IC; 
				    code_table[IC].code |= (i<<ARE_SKIP);
				
			    }
	    } /* end of for loop */ 

	    IC++;
	}	
			
}/* end of function */


/*this function search for the operands after the 2 operand instruction found.
if found , without any ERRORS, will send it to the kidud2 funcion to code it */
bool searchOp2(info_of_line line_info, table *code_table, int i)
{
	
	int j;
	bool found = false;
	char* tok;
	value addrs1; /* addrs1,2 and 3 will represent the operands of the opcode */
    value addrs2;
    addrs_method address;

    /*important initialization because if the hashing method wont be found on the 
    SEARCHING LOOP , well stay with this value and return an ERROR */ 
    addrs1.adr = NONE_ADDRS;
    addrs2.adr = NONE_ADDRS;

	tok = strtok(line_info.text, ",");
        /*saving the names of the 2 operands on the while loop */
        while (tok != NULL)
        {	SKIP_WHITESPACE(tok);
        	address = addressType(tok);                 
            if (!found)
            {
            	/* SEARCHING LOOP*/ 
                for(j=0;j < opCodeVal2Op[i].opSourceLen ;j++)
                {
                	if (address == opCodeVal2Op[i].opSource[j])
                    {
                    	/* saved the first operand , now when found is true , on the 									   next iteration will save the second one */
                        found = true; /* found the first operand. next iteration well check 										  the other thanks to this boolian value */
                        addrs1.adr = address;
                        addrs1.opName = tok;        
                    }
                }
            }
            else
            {   
			    /* SEARCHING LOOP*/ 
                for(j=0;j < opCodeVal2Op[i].opDestinLen ;j++)
                {
                    if (address == opCodeVal2Op[i].opDestination[j])
                    {                       
                        addrs2.adr = address;
                        addrs2.opName = tok;                               
                    }
                } /* end of inside for loop */                     
		    }

		    tok = strtok(NULL, ",");                            
      	} /* end of while loop */

      	if (addrs1.adr == NONE_ADDRS || addrs2.adr == NONE_ADDRS)
      	{ 
			/* illegal operand types */
            printf("File->%s:line->%ld:",line_info.file_name,line_info.line_num);
            printf("ERROR: The input String is Wrong because of illegal operand types\n");
            return false;
        }

        else
        {
           	kidud2(addrs1,addrs2,i, (code_table));               
        	return true;
        }
        if (strchr(addrs2.opName,'\n'))
            {
                *strchr(addrs2.opName,'\n') = '\0';
            }                
}/* end of functions */

/* coding the operators of the 2 operator instruction type to the instructions table */ 
void kidud2 (value addrs1,value addrs2,int index,  table *code_table)
{
	int i;	
	if ( addrs1.adr == DIRECT_REG && addrs2.adr == DIRECT_REG ) /* check for params */
	{  /*coding opcode for this case */
        code_table[IC].address = IC;  
		code_table[IC].code |= (TWO_REG_HASH<<ARE_SKIP);
		code_table[IC].code |= ((opCodeVal2Op[index].commandNumber)<<OPCODE_SKIP);
		IC++;

		/*finding the register number and coding according to it */ 
		for ( i = 0 ;i < REG_NUMBER ; i++)
		{
			if (!strcmp(addrs1.opName,registers[i]))
			{ /* register found! */ 
				code_table[IC].code |= (i<<SOURCE_REG_SKIP);				
			}
		}	/* end of for loop */	

		code_table[IC].address = IC;	
	
		/*finding the register number and coding according to it */ 
		for ( i = 0 ;i < REG_NUMBER ; i++)
		{	
			if (!strncmp(addrs2.opName,registers[i],2))
			{ 			
				code_table[IC].code |= (i<<ARE_SKIP);
				IC++;
			}
		}		
	}

	else 
	{
		/*coding opcode for this case */
    	code_table[IC].address = IC;    
		code_table[IC].code |= ((opCodeVal2Op[index].commandNumber)<<OPCODE_SKIP);
		code_table[IC].code |= (addrs1.adr<<HASH_SOURCE_OP);
		code_table[IC].code |= (addrs2.adr<<ARE_SKIP);
		IC++;
		if (addrs1.adr == IMMEDIATE)/* if its the first hashing method */
		{
    	    code_table[IC].address = IC;
		    code_table[IC].code |= atoi(addrs1.opName+1)<<ARE_SKIP; 
		    IC++;
		}

		else if (addrs1.adr == DIRECT)/* if its the second hashing method */
		{
		    /*not coding. will be coded on the next pass */
		    code_table[IC].address = IC;
		    IC++;
		}

		else if (addrs1.adr == DIRECT_REG)/* if its the forth hashing method */
		{
		    for ( i = 0 ;i < REG_NUMBER ; i++)
		    {
			    if (!strcmp(addrs1.opName,registers[i]))
			    { /* found the registernumber */
                    code_table[IC].address = IC;
				    code_table[IC].code |= (i<<SOURCE_REG_SKIP);
                    IC++;
			    }
		    }
	    }

		if (addrs2.adr == IMMEDIATE)/* if its the first hashing method */
		{
    	    code_table[IC].address = IC;
		    code_table[IC].code |= atoi(addrs2.opName+1)<<ARE_SKIP; 
		    IC++;
		}

		else if (addrs2.adr == DIRECT)/* if its the second hashing method */
		{
		    /*not coding. will be coded on the next pass */
    	    code_table[IC].address = IC;
		    IC++;
		}

		else if (addrs2.adr == DIRECT_REG)/* if its the forth hashing method */
		{
		    /*finding the register number and coding according to it */ 
		    for ( i = 0 ;i < REG_NUMBER ; i++)
		    {
			    if (!strcmp(addrs2.opName, registers[i]))
			    {
                    code_table[IC].address = IC; 
				    code_table[IC].code |= (i<<SOURCE_REG_SKIP);
			    }
		    }
		    IC++;
		}	
	}		
} /* end of function */
